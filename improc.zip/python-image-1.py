#! /usr/bin/env python3
#Python program to read image using matplotlib

import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np

img = mpimg.imread('newSample.png')

print(type(img))

lum_img0 = img[:,:,0] #R
lum_img1 = img[:,:,1] #G
lum_img2 = img[:,:,2] #B

test_image = lum_img0 + lum_img1 + lum_img2

#print(img)
#print(test_image)

#print(img)
#plt.imshow(img)
#plt.show()

#plt.imshow(lum_img0)
#plt.colorbar()
#plt.show()

#manipulating lum_img2
row, column = lum_img2.shape
print(row,column)
array1 = np.ndarray((row,column))
array2 = np.ndarray((row,column))
array1[:,:] = lum_img2[:,:]
array2[:,:] = lum_img2[:,:]

'''
fig1 = plt.figure()
b = fig1.add_subplot(1,1,1)
imgplot = plt.imshow(array1)
imgplot.set_clim(0.0, 0.7)
b.set_title('Sample')
plt.colorbar(ticks=[0.1, 0.3, 0.5, 0.7], orientation='horizontal')
plt.show()
'''

#Laplacian filter
for iter in range(10):
    for i in range(1,row-1):
        for j in range(1,column-1):
            if array2[i][j] < 0.3:
                array2[i][j] = ( array1[i-1][j] + array1[i+1][j] \
                                 + array1[i][j-1] +array1[i][j+1])*0.25


    #updating array
    array1[:,:] = array2[:,:]
            

#multigrid enhancement
#reset value
array1[:,:] = lum_img2[:,:]
array2[:,:] = lum_img2[:,:]

rownew = 2*row
colnew = 2*column
array3 = np.zeros((rownew,colnew))
#initial value for array3
for i in range(row):
    for j in range(column):
        array3[2*i][2*j] = array1[i][j]


#interpolation
#i-sweep
wb = 0.5
w1 = 0.5
w2 = 0.5
for i in range(1,rownew-1):
    for j in range(colnew):
        if array3[i][j] == 0.0:
            f1 = array3[i-1][j]
            f2 = array3[i+1][j]
            eps = f1 - f2
            if eps > 0.0:
                w1 = 0.7
                w2 = 0.3
            #array3[i][j] = 0.5*(array3[i-1][j] + array3[i+1][j])
            array3[i][j] = w1*array3[i-1][j] + w2*array3[i+1][j]

for i in range(rownew):
    for j in range(1,colnew-1):
        if array3[i][j] == 0.0:
            f1 = array3[i][j-1]
            f2 = array3[i][j+1]
            eps = f1 - f2
            if eps > 0.0:
                w1 = 0.7
                w2 = 0.3

            #array3[i][j] = 0.5*(array3[i][j-1] + array3[i][j+1])
            array3[i][j] = w1*array3[i][j-1] + w2*array3[i][j+1]

        
    
fig1 = plt.figure()
b = fig1.add_subplot(1,2,1)
imgplot = plt.imshow(lum_img2)
imgplot.set_clim(0.0, 0.7)
b.set_title('Sample')
plt.colorbar(ticks=[0.1, 0.3, 0.5, 0.7], orientation='horizontal')
b = fig1.add_subplot(1,2,2)
imgplot = plt.imshow(array3)
imgplot.set_clim(0.0, 0.7)
b.set_title('Laplacian')
plt.colorbar(ticks=[0.1, 0.3, 0.5, 0.7], orientation='horizontal')

plt.show()


'''
fig = plt.figure()
a = fig.add_subplot(1,2,1)
imgplot = plt.imshow(lum_img2)
imgplot.set_clim(0.0, 0.7)
a.set_title('2-slice')
plt.colorbar(ticks=[0.1, 0.3, 0.5, 0.7], orientation='horizontal')
a = fig.add_subplot(1,2,2)
imgplot = plt.imshow(img)
imgplot.set_clim(0.0, 0.7)
a.set_title('original')
plt.colorbar(ticks=[0.1, 0.3, 0.5, 0.7], orientation='horizontal')
plt.show()
'''
